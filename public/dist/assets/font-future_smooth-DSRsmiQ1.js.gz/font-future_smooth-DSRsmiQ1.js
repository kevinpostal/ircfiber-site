const A=`tlf2a 3 3 8 -1 28 0 0 0
===============================================================================
  This is "Future Smooth" (Future Smooth.flf), based on "Future" (future.tlf) by Sam Hocevar. This variant uses arcs instead of sharp corners to smooth out the font. Because heavy arc characters don't exist, the font uses light box drawings instead of heavy ones for consistency.

  2006/10/01 -- Sam Hocevar <sam@hocevar.net>
                font creation
                still missing: # % ( ) * / < > \\ ^ ~
  2006/10/02 -- Sam Hocevar <sam@hocevar.net>
                added Unicode block and line glyphs
                added: % ( ) * / \\ ~
                fixed: & 2 5 X
  2026/02/19 -- John Goodliff <johng.io>
                replaced ┏ with ╭
                replaced ┓ with ╮
                replaced ┗ with ╰
                replaced ┛ with ╯
                replaced heavy box drawings with light box drawings

  This font is free software. It comes without any warranty, to the extent
permitted by applicable law. You can redistribute it and/or modify it under
the terms of the Do What The Fuck You Want To Public License, Version 2,
as published by Sam Hocevar. See http://sam.zoy.org/wtfpl/COPYING for more
details.

  Missing characters: # < > ^

  This font is part of TOIlet’s official distribution. More information
on the TOIlet website at http://caca.zoy.org/wiki/toilet
===============================================================================
  @
  @
  @@
╷!
╵!
╵!!
╷╷"
  "
  ""
 @
 @
#@@
╭┬╮$
╰┼╮$
╰┴╯$$
╭╮╷%
╭─╯%
╵╰╯%%
╭╮  &
│╶┼╴&
╰─╯ &&
╷'
 '
 ''
╭╴(
│ (
╰╴((
╶╮)
 │)
╶╯))
╷ ╷*
╶┼╴*
╵ ╵**
 ╷ +
╶┼╴+
 ╵ ++
  ,
  ,
 ╯,,
   -
╶─╴-
   --
 .
 .
╵..
 ╷/
╭╯/
╵ //
╭─╮0
│││0
╰─╯00
╶╮ 1
 │ 1
╶┴╴11
╭─╮2
╭─╯2
╰─╴22
╭─╮3
╶─┤3
╰─╯33
╷ ╷4
╰─┤4
  ╵44
╭─╴5
╰─╮5
╰─╯55
╭─╮6
├─╮6
╰─╯66
╭─╮7
  │7
  ╵77
╭─╮8
├─┤8
╰─╯88
╭─╮9
╰─┤9
╰─╯99
 :
╵:
╵::
  ;
 ╵;
 ╯;;
 @
 @
<@@
   =
╶─╴=
╶─╴==
 @
 @
>@@
╭─╮?
 ╶╯?
 ╵ ??
╭─╮@
│├╯@
╰─╴@@
╭─╮A
├─┤A
╵ ╵AA
╭╮ B
├┴╮B
╰─╯BB
╭─╴C
│  C
╰─╴CC
╶┬╮D
 ││D
╶┴╯DD
╭─╴E
├╴ E
╰─╴EE
╭─╴F
├╴ F
╵  FF
╭─╴G
│╶╮G
╰─╯GG
╷ ╷H
├─┤H
╵ ╵HH
╷I
│I
╵II
 ╭╮J
  │J
╰─╯JJ
╷╭ K
├┴╮K
╵ ╵KK
╷  L
│  L
╰─╴LL
╭┬╮M
│││M
╵ ╵MM
╭╮╷N
│╰┤N
╵ ╵NN
╭─╮O
│ │O
╰─╯OO
╭─╮P
├─╯P
╵  PP
╭─╮Q
│╮│Q
╰┴╯QQ
╭─╮R
├┬╯R
╵╰╴RR
╭─╮S
╰─╮S
╰─╯SS
╶┬╴T
 │ T
 ╵ TT
╷ ╷U
│ │U
╰─╯UU
╷ ╷V
│╭╯V
╰╯ VV
╷ ╷W
│╷│W
╰┴╯WW
╷ ╷X
╭┼╯X
╵ ╵XX
╷ ╷Y
╰┬╯Y
 ╵ YY
╶─╮Z
╭─╯Z
╰─╴ZZ
╭─ [
│  [
╰─ [[
╷ \\
╰╮\\
 ╵\\\\
 ─╮]
  │]
 ─╯]]
 @
 @
^@@
   _
   _
╶─╴__
 ╮\`
  \`
  \`\`
╭─╮a
├─┤a
╵ ╵aa
╭╮ b
├┴╮b
╰─╯bb
╭─╴c
│  c
╰─╴cc
╶┬╮d
 ││d
╶┴╯dd
╭─╴e
├╴ e
╰─╴ee
╭─╴f
├╴ f
╵  ff
╭─╴g
│╶╮g
╰─╯gg
╷ ╷h
├─┤h
╵ ╵hh
╷i
│i
╵ii
 ╭╮j
  │j
╰─╯jj
╷╭ k
├┴╮k
╵ ╵kk
╷  l
│  l
╰─╴ll
╭┬╮m
│││m
╵ ╵mm
╭╮╷n
│╰┤n
╵ ╵nn
╭─╮o
│ │o
╰─╯oo
╭─╮p
├─╯p
╵  pp
╭─╮q
│╮│q
╰┴╯qq
╭─╮r
├┬╯r
╵╰╴rr
╭─╮s
╰─╮s
╰─╯ss
╶┬╴t
 │ t
 ╵ tt
╷ ╷u
│ │u
╰─╯uu
╷ ╷v
│╭╯v
╰╯ vv
╷ ╷w
│╷│w
╰┴╯ww
╷ ╷x
╭┼╯x
╵ ╵xx
╷ ╷y
╰┬╯y
 ╵ yy
╶─╮z
╭─╯z
╰─╴zz
 ╭╴{
╶┤ {
 ╰╴{{
╷|
│|
╵||
╶╮ }
 ├╴}
╶╯ }}
   ~
╭─╯~
   ~~
╭─╮╭─╴Ä
├─┤├╴ Ä
╵ ╵╰─╴ÄÄ
╭─╮╭─╴Ö
│ │├╴ Ö
╰─╯╰─╴ÖÖ
╷ ╷╭─╴Ü
│ │├╴ Ü
╰─╯╰─╴ÜÜ
╭─╮╭─╴ä
├─┤├╴ ä
╵ ╵╰─╴ää
╭─╮╭─╴ö
│ │├╴ ö
╰─╯╰─╴öö
╷ ╷╭─╴ü
│ │├╴ ü
╰─╯╰─╴üü
╭─╮╭─╮ß
╰─╮╰─╮ß
╰─╯╰─╯ßß
0x2500 ─ BOX DRAWINGS LIGHT HORIZONTAL
   @
───@
   @@
0x2501 ━ BOX DRAWINGS HEAVY HORIZONTAL
   @
■■■@
   @@
0x2502 │ BOX DRAWINGS LIGHT VERTICAL
 │ @
 │ @
 │@@
0x2503 ┃ BOX DRAWINGS HEAVY VERTICAL
 █ @
 █ @
 █@@
0x250C ┌ BOX DRAWINGS LIGHT DOWN AND RIGHT
   @
 ╭─@
 │ @@
0x250F ┏ BOX DRAWINGS HEAVY DOWN AND RIGHT
   @
 ▄■@
 █ @@
0x2510 ┐ BOX DRAWINGS LIGHT DOWN AND LEFT
   @
─╮ @
 │@@
0x2513 ┓ BOX DRAWINGS HEAVY DOWN AND LEFT
   @
■▄ @
 █@@
0x2514 └ BOX DRAWINGS LIGHT UP AND RIGHT
 │ @
 ╰─@
   @@
0x2517 ┗ BOX DRAWINGS HEAVY UP AND RIGHT
 █ @
 ▀■@
   @@
0x2518 ┘ BOX DRAWINGS LIGHT UP AND LEFT
 │ @
─╯ @
  @@
0x251B ┛ BOX DRAWINGS HEAVY UP AND LEFT
 █ @
■▀ @
  @@
0x251c ├ BOX DRAWINGS LIGHT VERTICAL AND RIGHT
 │ @
 ├─@
 │ @@
0x2523 ┣ BOX DRAWINGS HEAVY VERTICAL AND RIGHT
 █ @
 █■@
 █ @@
0x2524 ┤ BOX DRAWINGS LIGHT VERTICAL AND LEFT
 │ @
─┤ @
 │@@
0x252B ┫ BOX DRAWINGS HEAVY VERTICAL AND LEFT
 █ @
■█ @
 █@@
0x252c ┬ BOX DRAWINGS LIGHT DOWN AND HORIZONTAL
   @
─┬─@
 │ @@
0x2533 ┳ BOX DRAWINGS HEAVY DOWN AND HORIZONTAL
   @
■▄■@
 █ @@
0x2534 ┴ BOX DRAWINGS LIGHT UP AND HORIZONTAL
 │ @
─┴─@
   @@
0x253B ┻ BOX DRAWINGS HEAVY UP AND HORIZONTAL
 █ @
■▀■@
   @@
0x253c ┼ BOX DRAWINGS LIGHT VERTICAL AND HORIZONTAL
 │ @
─┼─@
 │ @@
0x254B ╋ BOX DRAWINGS HEAVY VERTICAL AND HORIZONTAL
 █ @
■█■@
 █ @@
0x2578 ╸ BOX DRAWINGS HEAVY LEFT
   @
■■ @
  @@
0x2579 ╹ BOX DRAWINGS HEAVY UP
 █ @
 ▀ @
  @@
0x257A ╺ BOX DRAWINGS HEAVY RIGHT
   @
 ■■@
   @@
0x257B ╻ BOX DRAWINGS HEAVY DOWN
   @
 ▄ @
 █@@
0x2580 ▀ UPPER HALF BLOCK
███@
▀▀▀@
   @@
0x2584 ▄ LOWER HALF BLOCK
   @
▄▄▄@
███@
0x2588 █ FULL BLOCK
███@
███@
███@@
0x25A0 ■ BLACK SQUARE
▄▄▄@
███@
▀▀▀@@
0x5350 卐 CJK UNIFIED IDEOGRAPH-5350
╷╭╴@
╰┼╮@
╶╯╵@@
0x534D 卍 CJK UNIFIED IDEOGRAPH-534D
╶╮╷@
╭┼╯@
╵╰╴@@
`;export{A as default};
