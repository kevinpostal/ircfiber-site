const t=`tlf2a 2 3 6 -1 15 0 0 0
===============================================================================
  This is smbraille.tlf", or “Small Braille”, by Sam Hocevar <sam@hocevar.net>.
It was created on September 30th, 2006.

  This font is free software. It comes without any warranty, to the extent
permitted by applicable law. You can redistribute it and/or modify it under
the terms of the Do What The Fuck You Want To Public License, Version 2,
as published by Sam Hocevar. See http://sam.zoy.org/wtfpl/COPYING for more
details.

  Missing characters: # $ % & * + , : ; < > ?

  This font is part of TOIlet’s official distribution. More information
on the TOIlet website at http://caca.zoy.org/wiki/toilet
===============================================================================
 @
 @@
 ⡇!
 ⠅!!
 ⠃⠃"
   ""
 @
#@@
 @
$@@
 @
%@@
 @
&@@
 ⠃'
  ''
 ⡔⠁(
 ⠣⡀((
 ⠈⢢)
 ⢀⠜))
 @
*@@
 @
+@@
 @
,@@
   -
 ⠉⠉--
  .
 ⠶..
  ⡜/
 ⠎ //
 ⣎⣵0
 ⠫⠜00
 ⢺ 1
 ⠼⠄11
 ⠊⡱2
 ⠮⠤22
 ⢉⡹3
 ⠤⠜33
 ⢇⣸4
  ⠸44
 ⣏⡉5
 ⠤⠜55
 ⣎⡁8
 ⠣⠜88
 ⠉⡹7
 ⠸ 77
 ⢎⡱8
 ⠣⠜88
 ⢎⣱9
 ⠠⠜99
 @
:@@
 @
;@@
 @
<@@
 ⣀⣀=
 ⠒⠒==
 @
>@@
 @
?@@
 ⣎⣱@
 ⠫⠥@@
 ⣎⣱A
 ⠇⠸AA
 ⣏⡱B
 ⠧⠜BB
 ⡎⠑C
 ⠣⠔CC
 ⡏⢱D
 ⠧⠜DD
 ⣏⡉E
 ⠧⠤EE
 ⣏⡉F
 ⠇ FF
 ⡎⠑G
 ⠣⠝GG
 ⣇⣸H
 ⠇⠸HH
 ⡇I
 ⠇II
 ⠈⢹J
 ⠣⠜JJ
 ⣇⠜K
 ⠇⠱KK
 ⡇ L
 ⠧⠤LL
 ⡷⢾M
 ⠇⠸MM
 ⡷⣸N
 ⠇⠹NN
 ⡎⢱O
 ⠣⠜OO
 ⣏⡱P
 ⠇ PP
 ⡎⢱Q
 ⠣⠪QQ
 ⣏⡱R
 ⠇⠱RR
 ⢎⡑S
 ⠢⠜SS
 ⢹⠁T
 ⠸ TT
 ⡇⢸U
 ⠣⠜UU
 ⡇⢸V
 ⠸⠃VV
 ⡇⢸W
 ⠟⠻WW
 ⢇⡸X
 ⠇⠸XX
 ⢇⢸Y
  ⠇YY
 ⢉⠝Z
 ⠮⠤ZZ
 ⡏[
 ⣇[[
 ⢣ \\
  ⠱\\\\
 ⢹]
 ⣸]]
 ⠊⠂^
   ^^
   _
 ⠤⠤__
 ⠑\`
  \`\`
 ⢀⣀a
 ⠣⠼aa
 ⣇⡀b
 ⠧⠜bb
 ⢀⣀c
 ⠣⠤cc
 ⢀⣸d
 ⠣⠼dd
 ⢀⡀e
 ⠣⠭ee
 ⣰⡁f
 ⢸ ff
 ⢀⡀g
 ⣑⡺gg
 ⣇⡀h
 ⠇⠸hh
 ⠄i
 ⠇ii
 ⠠j
 ⡸jj
 ⡇⡠k
 ⠏⠢kk
 ⡇l
 ⠣ll
 ⣀⣀ m
 ⠇⠇⠇mm
 ⣀⡀n
 ⠇⠸nn
 ⢀⡀o
 ⠣⠜oo
 ⣀⡀p
 ⡧⠜pp
 ⢀⣀q
 ⠣⢼qq
 ⡀⣀r
 ⠏ rr
 ⢀⣀s
 ⠭⠕ss
 ⣰⡀t
 ⠘⠤tt
 ⡀⢀u
 ⠣⠼uu
 ⡀⢀v
 ⠱⠃vv
 ⡀ ⢀w
 ⠱⠱⠃ww
 ⡀⢀x
 ⠜⠣xx
 ⡀⢀y
 ⣑⡺yy
 ⣀⣀z
 ⠴⠥zz
 ⡰⠁{
 ⠘⠄{{
 ⡇|
 ⠇||
 ⠈⢆}
 ⠠⠃}}
 ⡠⡠~
   ~~
 ⣕⣪Ä
 ⠇⠸ÄÄ
 ⡕⢪Ö
 ⠣⠜ÖÖ
 ⡅⢨Ü
 ⠣⠜ÜÜ
 ⢂⣐ä
 ⠣⠼ää
 ⢂⡐ö
 ⠣⠜öö
 ⡂⢐ü
 ⠣⠼üü
 ⡔⡢ß
 ⡇⠜ßß
`;export{t as default};
