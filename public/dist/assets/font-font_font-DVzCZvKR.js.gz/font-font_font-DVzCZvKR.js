const t=`\uFEFFflf2a$ 11 11 30 0 5 0 0 0
Font Author: Oscar Cole

This font is free to use and distribute / MIT License

FIGFont created with: http://patorjk.com/figfont-editor
$    $@
$    $@
$    $@
$    $@
$    $@
$    $@
$    $@
$    $@
$    $@
$    $@
$    $@@
font$@
font$@
font$@
font$@
font$@
font$@
font$@
    $@
font$@
    $@
    $@@
font    font$@
font    font$@
            $@
            $@
            $@
            $@
            $@
            $@
            $@
            $@
            $@@
    font    font    $@
    font    font    $@
fontfontfontfontfont$@
    font    font    $@
    font    font    $@
    font    font    $@
fontfontfontfontfont$@
    font    font    $@
    font    font    $@
                    $@
                    $@@
    fontfont    $@
fontfontfontfont$@
font  font  font$@
font  font      $@
fontfontfont    $@
    fontfontfont$@
      font  font$@
font  font  font$@
fontfontfontfont$@
                $@
                $@@
    font        font        $@
font    font    font        $@
    font    fontfont        $@
            font            $@
        fontfont            $@
        font        font    $@
        font    font    font$@
        font        font    $@
                            $@
                            $@
                            $@@
        font    $@
    font    font$@
        font    $@
    fontfont    $@
font    font    $@
font    font    $@
font    fontfont$@
font    font    $@
    fontfontfont$@
                $@
                $@@
font$@
font$@
    $@
    $@
    $@
    $@
    $@
    $@
    $@
    $@
    $@@
        font$@
    font    $@
font        $@
font        $@
font        $@
font        $@
font        $@
    font    $@
        font$@
            $@
            $@@
font        $@
    font    $@
        font$@
        font$@
        font$@
        font$@
        font$@
    font    $@
font        $@
            $@
            $@@
    font    $@
fontfontfont$@
    font    $@
 font  font $@
            $@
            $@
            $@
            $@
            $@
            $@
            $@@
            $@
            $@
    font    $@
    font    $@
fontfontfont$@
    font    $@
    font    $@
            $@
            $@
            $@
            $@@
                $@
                $@
                $@
                $@
                $@
                $@
            font$@
            font$@
            font$@
                $@
                $@@
                $@
                $@
                $@
                $@
fontfontfontfont$@
                $@
                $@
                $@
                $@
                $@
                $@@
                $@
                $@
                $@
                $@
                $@
                $@
                $@
            font$@
            font$@
                $@
                $@@
        font$@
        font$@
        font$@
    fontfont$@
    font    $@
fontfont    $@
font        $@
font        $@
font        $@
            $@
            $@@
    font    $@
fontfontfont$@
font    font$@
font    font$@
font    font$@
font    font$@
font    font$@
fontfontfont$@
    font    $@
            $@
            $@@
fontfont    $@
    font    $@
    font    $@
    font    $@
    font    $@
    font    $@
    font    $@
    font    $@
fontfontfont$@
            $@
            $@@
fontfontfont    $@
        fontfont$@
            font$@
        fontfont$@
    fontfont    $@
fontfont        $@
font            $@
font            $@
fontfontfontfont$@
                $@
                $@@
    fontfont    $@
fontfontfontfont$@
            font$@
        fontfont$@
    fontfont    $@
        fontfont$@
            font$@
fontfontfontfont$@
    fontfont    $@
                $@
                $@@
            font    $@
        fontfont    $@
    fontfontfont    $@
fontfont    font    $@
font        font    $@
fontfontfontfontfont$@
            font    $@
            font    $@
            font    $@
                    $@
                    $@@
fontfontfontfont$@
font            $@
font            $@
fontfontfont    $@
        fontfont$@
            font$@
            font$@
        fontfont$@
fontfontfont    $@
                $@
                $@@
    fontfontfont$@
fontfont        $@
font            $@
font            $@
fontfontfont    $@
font    fontfont$@
font        font$@
fontfontfontfont$@
    fontfont    $@
                $@
                $@@
fontfontfontfont $@
            font $@
            font $@
         fontfont$@
     fontfont    $@
     font        $@
     font        $@
     font        $@
     font        $@
                 $@
                 $@@
    fontfont    $@
fontfontfontfont$@
font        font$@
fontfontfontfont$@
    fontfont    $@
fontfontfontfont$@
font        font$@
fontfontfontfont$@
    fontfont    $@
                $@
                $@@
    fontfont    $@
fontfontfontfont$@
font        font$@
fontfontfontfont$@
    fontfontfont$@
            font$@
            font$@
            font$@
            font$@
                $@
                $@@
    $@
    $@
font$@
font$@
    $@
font$@
font$@
    $@
    $@
    $@
    $@@
    $@
    $@
font$@
font$@
    $@
font$@
font$@
font$@
    $@
    $@
    $@@
            $@
            $@
            $@
    fontfont$@
fontfont    $@
    fontfont$@
            $@
            $@
            $@
            $@
            $@@
        $@
        $@
        $@
fontfont$@
        $@
fontfont$@
        $@
        $@
        $@
        $@
        $@@
            $@
            $@
            $@
fontfont    $@
    fontfont$@
fontfont    $@
            $@
            $@
            $@
            $@
            $@@
    fontfont    $@
fontfontfontfont$@
font        font$@
            font$@
        fontfont$@
        font    $@
        font    $@
                $@
        font    $@
                $@
                $@@
        fontfont        $@
    font        font    $@
font                font$@
font                font$@
font        @       font$@
font                font$@
font                font$@
    font                $@
        fontfontfontfont$@
                        $@
                        $@@
        font        $@
      fontfont      $@
    fontfontfont    $@
  font        font  $@
fontfontfontfontfont$@
font            font$@
font            font$@
font            font$@
font            font$@
                    $@
                    $@@
fontfontfont    $@
font    fontfont$@
font        font$@
font        font$@
fontfontfontfont$@
font        font$@
font        font$@
font    fontfont$@
fontfontfont    $@
                $@
                $@@
    fontfontfont    $@
fontfont    fontfont$@
font                $@
font                $@
font                $@
font                $@
font                $@
fontfont    fontfont$@
    fontfontfont    $@
                    $@
                    $@@
fontfontfont    $@
font    fontfont$@
font        font$@
font        font$@
font        font$@
font        font$@
font        font$@
font    fontfont$@
fontfontfont    $@
                $@
                $@@
fontfontfontfont$@
font            $@
font            $@
font            $@
fontfontfontfont$@
font            $@
font            $@
font            $@
fontfontfontfont$@
                $@
                $@@
fontfontfontfont$@
font            $@
font            $@
font            $@
fontfontfontfont$@
font            $@
font            $@
font            $@
font            $@
                $@
                $@@
    fontfontfont    $@
fontfont    fontfont$@
font                $@
font                $@
font                $@
font        fontfont$@
font            font$@
fontfont    fontfont$@
    fontfontfont    $@
                    $@
                    $@@
font        font$@
font        font$@
font        font$@
font        font$@
fontfontfontfont$@
font        font$@
font        font$@
font        font$@
font        font$@
                $@
                $@@
fontfontfont$@
    font    $@
    font    $@
    font    $@
    font    $@
    font    $@
    font    $@
    font    $@
fontfontfont$@
            $@
            $@@
fontfontfont    $@
    font        $@
    font        $@
    font        $@
    font        $@
    font        $@
    font        $@
    font    font$@
    fontfontfont$@
                $@
                $@@
font        font$@
font        font$@
font    fontfont$@
fontfontfont    $@
fontfont        $@
fontfontfont    $@
font    fontfont$@
font        font$@
font        font$@
                $@
                $@@
font            $@
font            $@
font            $@
font            $@
font            $@
font            $@
font            $@
font            $@
fontfontfontfont$@
                $@
                $@@
font            font$@
fontfont    fontfont$@
fontfontfontfontfont$@
font    font    font$@
font            font$@
font            font$@
font            font$@
font            font$@
font            font$@
                    $@
                    $@@
fontfont    font$@
fontfontfontfont$@
font    fontfont$@
font        font$@
font        font$@
font        font$@
font        font$@
font        font$@
font        font$@
                $@
                $@@
    fontfont    $@
fontfontfontfont$@
font        font$@
font        font$@
font        font$@
font        font$@
font        font$@
fontfontfontfont$@
    fontfont    $@
                $@
                $@@
fontfontfont    $@
font    fontfont$@
font    fontfont$@
fontfontfont    $@
font            $@
font            $@
font            $@
font            $@
font            $@
                $@
                $@@
    fontfont        $@
fontfontfontfont    $@
font        font    $@
font        font    $@
font        font    $@
font        font    $@
font        font    $@
fontfontfontfont    $@
    fontfontfontfont$@
                    $@
                    $@@
fontfontfont    $@
font    fontfont$@
font    fontfont$@
fontfontfont    $@
font    fontfont$@
font        font$@
font        font$@
font        font$@
font        font$@
                $@
                $@@
    fontfont    $@
fontfontfontfont$@
font        font$@
font            $@
fontfontfont    $@
    fontfontfont$@
            font$@
font        font$@
fontfontfontfont$@
                $@
                $@@
fontfontfont$@
    font    $@
    font    $@
    font    $@
    font    $@
    font    $@
    font    $@
    font    $@
    font    $@
            $@
            $@@
font    font$@
font    font$@
font    font$@
font    font$@
font    font$@
font    font$@
font    font$@
fontfontfont$@
    font    $@
            $@
            $@@
font            font$@
font            font$@
fontfont    fontfont$@
    font    font    $@
    font    font    $@
    font    font    $@
    fontfontfont    $@
        font        $@
                    $@
                    $@
                    $@@
font    font    font$@
font    font    font$@
font    font    font$@
font    font    font$@
font    font    font$@
font    font    font$@
font    font    font$@
fontfontfontfontfont$@
    font    font    $@
                    $@
                    $@@
font    font$@
font    font$@
font    font$@
fontfontfont$@
    font    $@
fontfontfont$@
font    font$@
font    font$@
font    font$@
            $@
            $@@
font    font$@
font    font$@
font    font$@
fontfontfont$@
    font    $@
    font    $@
    font    $@
    font    $@
    font    $@
            $@
            $@@
fontfontfontfont$@
            font$@
            font$@
        fontfont$@
    fontfont    $@
fontfont        $@
font            $@
font            $@
fontfontfontfont$@
                $@
                $@@
fontfont$@
font    $@
font    $@
font    $@
font    $@
font    $@
font    $@
font    $@
fontfont$@
        $@
        $@@
font        $@
font        $@
font        $@
fontfont    $@
    font    $@
    fontfont$@
        font$@
        font$@
        font$@
            $@
            $@@
fontfont$@
    font$@
    font$@
    font$@
    font$@
    font$@
    font$@
    font$@
fontfont$@
        $@
        $@@
    font    $@
fontfontfont$@
font    font$@
font    font$@
            $@
            $@
            $@
            $@
            $@
            $@
            $@@
                $@
                $@
                $@
                $@
                $@
                $@
                $@
                $@
fontfontfontfont$@
                $@
                $@@
fontfont    $@
    fontfont$@
            $@
            $@
            $@
            $@
            $@
            $@
            $@
            $@
            $@@
        font        $@
      fontfont      $@
    fontfontfont    $@
  font        font  $@
fontfontfontfontfont$@
font            font$@
font            font$@
font            font$@
font            font$@
                    $@
                    $@@
fontfontfont    $@
font    fontfont$@
font        font$@
font        font$@
fontfontfontfont$@
font        font$@
font        font$@
font    fontfont$@
fontfontfont    $@
                $@
                $@@
    fontfontfont    $@
fontfont    fontfont$@
font                $@
font                $@
font                $@
font                $@
font                $@
fontfont    fontfont$@
    fontfontfont    $@
                    $@
                    $@@
fontfontfont    $@
font    fontfont$@
font        font$@
font        font$@
font        font$@
font        font$@
font        font$@
font    fontfont$@
fontfontfont    $@
                $@
                $@@
fontfontfontfont$@
font            $@
font            $@
font            $@
fontfontfontfont$@
font            $@
font            $@
font            $@
fontfontfontfont$@
                $@
                $@@
fontfontfontfont$@
font            $@
font            $@
font            $@
fontfontfontfont$@
font            $@
font            $@
font            $@
font            $@
                $@
                $@@
    fontfontfont    $@
fontfont    fontfont$@
font                $@
font                $@
font                $@
font        fontfont$@
font            font$@
fontfont    fontfont$@
    fontfontfont    $@
                    $@
                    $@@
font        font$@
font        font$@
font        font$@
font        font$@
fontfontfontfont$@
font        font$@
font        font$@
font        font$@
font        font$@
                $@
                $@@
fontfontfont$@
    font    $@
    font    $@
    font    $@
    font    $@
    font    $@
    font    $@
    font    $@
fontfontfont$@
            $@
            $@@
fontfontfont    $@
    font        $@
    font        $@
    font        $@
    font        $@
    font        $@
    font        $@
    font    font$@
    fontfontfont$@
                $@
                $@@
font        font$@
font        font$@
font    fontfont$@
fontfontfont    $@
fontfont        $@
fontfontfont    $@
font    fontfont$@
font        font$@
font        font$@
                $@
                $@@
font            $@
font            $@
font            $@
font            $@
font            $@
font            $@
font            $@
font            $@
fontfontfontfont$@
                $@
                $@@
font            font$@
fontfont    fontfont$@
fontfontfontfontfont$@
font    font    font$@
font            font$@
font            font$@
font            font$@
font            font$@
font            font$@
                    $@
                    $@@
fontfont    font$@
fontfontfontfont$@
font    fontfont$@
font        font$@
font        font$@
font        font$@
font        font$@
font        font$@
font        font$@
                $@
                $@@
    fontfont    $@
fontfontfontfont$@
font        font$@
font        font$@
font        font$@
font        font$@
font        font$@
fontfontfontfont$@
    fontfont    $@
                $@
                $@@
fontfontfont    $@
font    fontfont$@
font    fontfont$@
fontfontfont    $@
font            $@
font            $@
font            $@
font            $@
font            $@
                $@
                $@@
    fontfont        $@
fontfontfontfont    $@
font        font    $@
font        font    $@
font        font    $@
font        font    $@
font        font    $@
fontfontfontfont    $@
    fontfontfontfont$@
                    $@
                    $@@
fontfontfont    $@
font    fontfont$@
font    fontfont$@
fontfontfont    $@
font    fontfont$@
font        font$@
font        font$@
font        font$@
font        font$@
                $@
                $@@
    fontfont    $@
fontfontfontfont$@
font        font$@
font            $@
fontfontfont    $@
    fontfontfont$@
            font$@
font        font$@
fontfontfontfont$@
                $@
                $@@
fontfontfont$@
    font    $@
    font    $@
    font    $@
    font    $@
    font    $@
    font    $@
    font    $@
    font    $@
            $@
            $@@
font    font$@
font    font$@
font    font$@
font    font$@
font    font$@
font    font$@
font    font$@
fontfontfont$@
    font    $@
            $@
            $@@
font            font$@
font            font$@
fontfont    fontfont$@
    font    font    $@
    font    font    $@
    font    font    $@
    fontfontfont    $@
        font        $@
                    $@
                    $@
                    $@@
font    font    font$@
font    font    font$@
font    font    font$@
font    font    font$@
font    font    font$@
font    font    font$@
font    font    font$@
fontfontfontfontfont$@
    font    font    $@
                    $@
                    $@@
font    font$@
font    font$@
font    font$@
fontfontfont$@
    font    $@
fontfontfont$@
font    font$@
font    font$@
font    font$@
            $@
            $@@
font    font$@
font    font$@
font    font$@
fontfontfont$@
    font    $@
    font    $@
    font    $@
    font    $@
    font    $@
            $@
            $@@
fontfontfontfont$@
            font$@
            font$@
        fontfont$@
    fontfont    $@
fontfont        $@
font            $@
font            $@
fontfontfontfont$@
                $@
                $@@
    fontfont$@
    font    $@
    font    $@
    font    $@
fontfont    $@
    font    $@
    font    $@
    font    $@
    fontfont$@
            $@
            $@@
font$@
font$@
font$@
font$@
font$@
font$@
font$@
font$@
font$@
    $@
    $@@
fontfont    $@
    font    $@
    font    $@
    font    $@
    fontfont$@
    font    $@
    font    $@
    font    $@
fontfont    $@
            $@
            $@@
            $@
            $@
            $@
    fontfont$@
fontfont    $@
            $@
            $@
            $@
            $@
            $@
            $@@
       0font0       $@
      fontfont      $@
    fontfontfont    $@
  font        font  $@
fontfontfontfontfont$@
font            font$@
font            font$@
font            font$@
font            font$@
                    $@
                    $@@
   0fontfont0   $@
fontfontfontfont$@
font        font$@
font        font$@
font        font$@
font        font$@
font        font$@
fontfontfontfont$@
    fontfont    $@
                $@
                $@@
font 00 font$@
font    font$@
font    font$@
font    font$@
font    font$@
font    font$@
font    font$@
fontfontfont$@
    font    $@
            $@
            $@@
@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@
@@
fontfontfont    $@
font    fontfont$@
font        font$@
font        font$@
font    fontfont$@
font        font$@
font        font$@
font    fontfont$@
font    font    $@
                $@
                $@@
`;export{t as default};
