const t=`tlf2a 1 1 3 -1 15 0 0 0
===============================================================================
  This is wideterm.tlf, or “WideTerm”, by Sam Hocevar <sam@hocevar.net>. It was
created on August 2nd, 2007.

  This font is free software. It comes without any warranty, to the extent
permitted by applicable law. You can redistribute it and/or modify it under
the terms of the Do What The Fuck You Want To Public License, Version 2,
as published by Sam Hocevar. See http://sam.zoy.org/wtfpl/COPYING for more
details.

  Missing: Ä Ö Ü ä ö ü ß

  This font is part of TOIlet’s official distribution. More information
on the TOIlet website at http://caca.zoy.org/wiki/toilet
===============================================================================
@
！!
＂"
＃#
＄$
％%
＆&
＇'
（(
）)
＊*
＋+
，,
－-
．.
／/
０0
１1
２2
３3
４4
５5
６6
７7
８8
９9
：:
；;
＜<
＝=
＞>
？?
＠@
ＡA
ＢB
ＣC
ＤD
ＥE
ＦF
ＧG
ＨH
ＩI
ＪJ
ＫK
ＬL
ＭM
ＮN
ＯO
ＰP
ＱQ
ＲR
ＳS
ＴT
ＵU
ＶV
ＷW
ＸX
ＹY
ＺZ
［[
＼\\
］]
＾^
＿_
｀\`
ａa
ｂb
ｃc
ｄd
ｅe
ｆf
ｇg
ｈh
ｉi
ｊj
ｋk
ｌl
ｍm
ｎn
ｏo
ｐp
ｑq
ｒr
ｓs
ｔt
ｕu
ｖv
ｗw
ｘx
ｙy
ｚz
｛{
｜|
｝}
～~
Ä@
Ö@
Ü@
ä@
ö@
ü@
ß@
0x00a2 ¢ CENT SIGN
￠@
0x00a3 £ POUND SIGN
￡@
0x00ac ¬ NOT SIGN
￢@
0x00af ¯ MACRON
￣@
0x00a6 ¦ BROKEN BAR
￤@
0x00a5 ¥ YEN SIGN
￥@
0x20a9 ₩ WON SIGN
￦@
`;export{t as default};
